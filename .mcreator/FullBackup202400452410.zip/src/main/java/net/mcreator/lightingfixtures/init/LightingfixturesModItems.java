
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lightingfixtures.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.lightingfixtures.item.LikeItem;
import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LightingfixturesModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LightingfixturesMod.MODID);
	public static final DeferredItem<Item> CEILING = block(LightingfixturesModBlocks.CEILING);
	public static final DeferredItem<Item> SINGLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS);
	public static final DeferredItem<Item> SINGLETUBEFLUORESCENTLAMPS_1 = block(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS_1);
	public static final DeferredItem<Item> DOUBLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.DOUBLETUBEFLUORESCENTLAMPS);
	public static final DeferredItem<Item> THREETUBEFLUORESCENTLAMP = block(LightingfixturesModBlocks.THREETUBEFLUORESCENTLAMP);
	public static final DeferredItem<Item> FLUORESCENTLIGHTSFORCLASSROOMS = block(LightingfixturesModBlocks.FLUORESCENTLIGHTSFORCLASSROOMS);
	public static final DeferredItem<Item> CLASSROOM_LED_LIGHTS = block(LightingfixturesModBlocks.CLASSROOM_LED_LIGHTS);
	public static final DeferredItem<Item> FLUORESCENTLIGHTBULBS = block(LightingfixturesModBlocks.FLUORESCENTLIGHTBULBS);
	public static final DeferredItem<Item> LE_DPANELLIGHT = block(LightingfixturesModBlocks.LE_DPANELLIGHT);
	public static final DeferredItem<Item> LE_DCANOPYLIGHT_1_X_2 = block(LightingfixturesModBlocks.LE_DCANOPYLIGHT_1_X_2);
	public static final DeferredItem<Item> LE_DCANOPYLIGHT_2_X_2 = block(LightingfixturesModBlocks.LE_DCANOPYLIGHT_2_X_2);
	public static final DeferredItem<Item> ALUMINUMGUSSET = block(LightingfixturesModBlocks.ALUMINUMGUSSET);
	public static final DeferredItem<Item> ALUMINUMGUSSET_1_X_2 = block(LightingfixturesModBlocks.ALUMINUMGUSSET_1_X_2);
	public static final DeferredItem<Item> ALUMINUMGUSSET_2_X_2 = block(LightingfixturesModBlocks.ALUMINUMGUSSET_2_X_2);
	public static final DeferredItem<Item> FLUORESCENTCEILINGLIGHTS = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS);
	public static final DeferredItem<Item> FLUORESCENTCEILINGLIGHTS_2 = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_2);
	public static final DeferredItem<Item> FLUORESCENTCEILINGLIGHTS_1 = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_1);
	public static final DeferredItem<Item> SINGLESWITCHSWITCH = block(LightingfixturesModBlocks.SINGLESWITCHSWITCH);
	public static final DeferredItem<Item> DOUBLEOPENSWITCH = block(LightingfixturesModBlocks.DOUBLEOPENSWITCH);
	public static final DeferredItem<Item> THREEONSWITCH = block(LightingfixturesModBlocks.THREEONSWITCH);
	public static final DeferredItem<Item> QUADRUPLESWITCH = block(LightingfixturesModBlocks.QUADRUPLESWITCH);
	public static final DeferredItem<Item> LE_DFLOODLIGHTS = block(LightingfixturesModBlocks.LE_DFLOODLIGHTS);
	public static final DeferredItem<Item> LED_FLOOD_LIGHT_TOP = block(LightingfixturesModBlocks.LED_FLOOD_LIGHT_TOP);
	public static final DeferredItem<Item> LARGECYLINDERLAMP = block(LightingfixturesModBlocks.LARGECYLINDERLAMP);
	public static final DeferredItem<Item> MEDIUMDOWNLIGHT = block(LightingfixturesModBlocks.MEDIUMDOWNLIGHT);
	public static final DeferredItem<Item> SMALLDOWNLIGHTS = block(LightingfixturesModBlocks.SMALLDOWNLIGHTS);
	public static final DeferredItem<Item> ELECTRONICSINGLETUBEFLUORESCENTAMPS = block(LightingfixturesModBlocks.ELECTRONICSINGLETUBEFLUORESCENTAMPS);
	public static final DeferredItem<Item> ELECTRONICDOUBLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.ELECTRONICDOUBLETUBEFLUORESCENTLAMPS);
	public static final DeferredItem<Item> TRACKSPOTLIGHTS = block(LightingfixturesModBlocks.TRACKSPOTLIGHTS);
	public static final DeferredItem<Item> TRACKSPOTLIGHTS_1 = block(LightingfixturesModBlocks.TRACKSPOTLIGHTS_1);
	public static final DeferredItem<Item> METALHALIDEFLOODLIGHTS = block(LightingfixturesModBlocks.METALHALIDEFLOODLIGHTS);
	public static final DeferredItem<Item> METALHALIDEFLOODLIGHT = block(LightingfixturesModBlocks.METALHALIDEFLOODLIGHT);
	public static final DeferredItem<Item> FLUORESCENTLUMINAIRES = block(LightingfixturesModBlocks.FLUORESCENTLUMINAIRES);
	public static final DeferredItem<Item> ALUMINUMTUBESAREFLUORESCENT = block(LightingfixturesModBlocks.ALUMINUMTUBESAREFLUORESCENT);
	public static final DeferredItem<Item> ENERGYSAVINGLAMPMEDIUM = block(LightingfixturesModBlocks.ENERGYSAVINGLAMPMEDIUM);
	public static final DeferredItem<Item> ENERGYSAVINLAMPLARGE = block(LightingfixturesModBlocks.ENERGYSAVINLAMPLARGE);
	public static final DeferredItem<Item> ONEOPENTHREEPINSOCKET = block(LightingfixturesModBlocks.ONEOPENTHREEPINSOCKET);
	public static final DeferredItem<Item> TWOOPENTHREEPINSOCKET = block(LightingfixturesModBlocks.TWOOPENTHREEPINSOCKET);
	public static final DeferredItem<Item> SEVENPINSOCKET = block(LightingfixturesModBlocks.SEVENPINSOCKET);
	public static final DeferredItem<Item> T_VSOCKET = block(LightingfixturesModBlocks.T_VSOCKET);
	public static final DeferredItem<Item> INTERNETOUTLETS = block(LightingfixturesModBlocks.INTERNETOUTLETS);
	public static final DeferredItem<Item> GASMETERS = block(LightingfixturesModBlocks.GASMETERS);
	public static final DeferredItem<Item> RAIN_CS = block(LightingfixturesModBlocks.RAIN_CS);
	public static final DeferredItem<Item> ELECTRICALCABINETS_1X_1 = block(LightingfixturesModBlocks.ELECTRICALCABINETS_1X_1);
	public static final DeferredItem<Item> ELECTRICALCABINETS_1_X_2 = block(LightingfixturesModBlocks.ELECTRICALCABINETS_1_X_2);
	public static final DeferredItem<Item> ELECTRICALCABINETS_2X_2 = block(LightingfixturesModBlocks.ELECTRICALCABINETS_2X_2);
	public static final DeferredItem<Item> ELECTRICALCABINETS_2X_3 = block(LightingfixturesModBlocks.ELECTRICALCABINETS_2X_3);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER_1X_1 = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_1X_1);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER_2X_1 = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_1);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER_2X_2 = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_2);
	public static final DeferredItem<Item> ACCESSCONTROLINTERCOMHOST = block(LightingfixturesModBlocks.ACCESSCONTROLINTERCOMHOST);
	public static final DeferredItem<Item> ACCESSCONTROLINTERCOMEXTENSION = block(LightingfixturesModBlocks.ACCESSCONTROLINTERCOMEXTENSION);
	public static final DeferredItem<Item> IODINETUNGSTENLAMP = block(LightingfixturesModBlocks.IODINETUNGSTENLAMP);
	public static final DeferredItem<Item> DOUBLETUBECEILINGLIGHT = block(LightingfixturesModBlocks.DOUBLETUBECEILINGLIGHT);
	public static final DeferredItem<Item> DTUBECEILINGLIGHT = block(LightingfixturesModBlocks.DTUBECEILINGLIGHT);
	public static final DeferredItem<Item> ACCESSCONTROLINTERCOMEXTENSION_ON = block(LightingfixturesModBlocks.ACCESSCONTROLINTERCOMEXTENSION_ON);
	public static final DeferredItem<Item> SINGLE_TUBE_FLUORESCENT_LAMP_WITH_LAMPSHADE = block(LightingfixturesModBlocks.SINGLE_TUBE_FLUORESCENT_LAMP_WITH_LAMPSHADE);
	public static final DeferredItem<Item> DOUBLE_TUBE_SINGLESTAND_FLUORESCENT_LAMP_WITH_LAMPSHADE = block(LightingfixturesModBlocks.DOUBLE_TUBE_SINGLESTAND_FLUORESCENT_LAMP_WITH_LAMPSHADE);
	public static final DeferredItem<Item> DOUBLE_TUBE_FLUORESCENT_LAMPWITH_LAMPSHADE = block(LightingfixturesModBlocks.DOUBLE_TUBE_FLUORESCENT_LAMPWITH_LAMPSHADE);
	public static final DeferredItem<Item> THREE_LAMP_FLUORESCENT_LAMPWITH_LAMPSHADE = block(LightingfixturesModBlocks.THREE_LAMP_FLUORESCENT_LAMPWITH_LAMPSHADE);
	public static final DeferredItem<Item> FLUORESCENT_LAMP_HOLDERS = block(LightingfixturesModBlocks.FLUORESCENT_LAMP_HOLDERS);
	public static final DeferredItem<Item> FLUORESCENTDOUBLEBRACKET = block(LightingfixturesModBlocks.FLUORESCENTDOUBLEBRACKET);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER_2X_3 = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_3);
	public static final DeferredItem<Item> ELECTRICALBOXWITHELECTRICITYMETER_2X_380 = block(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_380);
	public static final DeferredItem<Item> TUNGSTENBULBS = block(LightingfixturesModBlocks.TUNGSTENBULBS);
	public static final DeferredItem<Item> WATERMETER = block(LightingfixturesModBlocks.WATERMETER);
	public static final DeferredItem<Item> FIVEPINSOCKET = block(LightingfixturesModBlocks.FIVEPINSOCKET);
	public static final DeferredItem<Item> T_VNETWORKSOCKET = block(LightingfixturesModBlocks.T_VNETWORKSOCKET);
	public static final DeferredItem<Item> DUALNETWORKOUTLETS = block(LightingfixturesModBlocks.DUALNETWORKOUTLETS);
	public static final DeferredItem<Item> HIGHPOWEROUTLETS = block(LightingfixturesModBlocks.HIGHPOWEROUTLETS);
	public static final DeferredItem<Item> LIKE = REGISTRY.register("like", LikeItem::new);
	public static final DeferredItem<Item> HEATINGPIPES = block(LightingfixturesModBlocks.HEATINGPIPES);
	public static final DeferredItem<Item> HEATINGPIPE = block(LightingfixturesModBlocks.HEATINGPIPE);
	public static final DeferredItem<Item> HEATINGBRANCHPIPE = block(LightingfixturesModBlocks.HEATINGBRANCHPIPE);
	public static final DeferredItem<Item> THEHEATINGIS = block(LightingfixturesModBlocks.THEHEATINGIS);
	public static final DeferredItem<Item> HEATINGINTERCONNECTIONPIPES = block(LightingfixturesModBlocks.HEATINGINTERCONNECTIONPIPES);
	public static final DeferredItem<Item> THEMAINCORNERPIPEOFTHEHEATER = block(LightingfixturesModBlocks.THEMAINCORNERPIPEOFTHEHEATER);
	public static final DeferredItem<Item> THEMAINHEATINGISTHE = block(LightingfixturesModBlocks.THEMAINHEATINGISTHE);
	public static final DeferredItem<Item> THEMAINBRANCHPIPEOFTHEHEATER = block(LightingfixturesModBlocks.THEMAINBRANCHPIPEOFTHEHEATER);
	public static final DeferredItem<Item> HEATINGSUPERVISOR = block(LightingfixturesModBlocks.HEATINGSUPERVISOR);
	public static final DeferredItem<Item> HEATINGMAINVALVE = block(LightingfixturesModBlocks.HEATINGMAINVALVE);
	public static final DeferredItem<Item> HEATINGBLEEDVALVE = block(LightingfixturesModBlocks.HEATINGBLEEDVALVE);
	public static final DeferredItem<Item> HEATINGA = block(LightingfixturesModBlocks.HEATINGA);
	public static final DeferredItem<Item> HEATINGB = block(LightingfixturesModBlocks.HEATINGB);
	public static final DeferredItem<Item> HEATINGC = block(LightingfixturesModBlocks.HEATINGC);
	public static final DeferredItem<Item> LAMPWARMTHBATH = block(LightingfixturesModBlocks.LAMPWARMTHBATH);
	public static final DeferredItem<Item> CEMOSPALCEPA = block(LightingfixturesModBlocks.CEMOSPALCEPA);
	public static final DeferredItem<Item> FIRE_EMERGENCY_LIGHT = block(LightingfixturesModBlocks.FIRE_EMERGENCY_LIGHT);
	public static final DeferredItem<Item> SMOKE_DETECTOR = block(LightingfixturesModBlocks.SMOKE_DETECTOR);
	public static final DeferredItem<Item> FIRE_ALARM_BUTTON = block(LightingfixturesModBlocks.FIRE_ALARM_BUTTON);
	public static final DeferredItem<Item> ALUMINUM_GRILLE = block(LightingfixturesModBlocks.ALUMINUM_GRILLE);
	public static final DeferredItem<Item> ALUMINUM_GRILLE_2 = block(LightingfixturesModBlocks.ALUMINUM_GRILLE_2);
	public static final DeferredItem<Item> ALUMINUM_TUBESARE_FLUORESCENT_2 = block(LightingfixturesModBlocks.ALUMINUM_TUBESARE_FLUORESCENT_2);
	public static final DeferredItem<Item> SUPERMARKE_TANTITHEFT_SYSTEM = block(LightingfixturesModBlocks.SUPERMARKE_TANTITHEFT_SYSTEM);
	public static final DeferredItem<Item> SUPERMARKET_SELF_CHECKOUT_SYSTEM = block(LightingfixturesModBlocks.SUPERMARKET_SELF_CHECKOUT_SYSTEM);
	public static final DeferredItem<Item> HIGH_POWER_ELECTRIC_METER_BOX = block(LightingfixturesModBlocks.HIGH_POWER_ELECTRIC_METER_BOX);
	public static final DeferredItem<Item> ELECTRICAL_CABINETS_1X1_380 = block(LightingfixturesModBlocks.ELECTRICAL_CABINETS_1X1_380);
	public static final DeferredItem<Item> ELECTRICAL_CABINETS_1X2_380 = block(LightingfixturesModBlocks.ELECTRICAL_CABINETS_1X2_380);
	public static final DeferredItem<Item> CORNER_TYPE_FLUORESCENT_LAMP = block(LightingfixturesModBlocks.CORNER_TYPE_FLUORESCENT_LAMP);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
