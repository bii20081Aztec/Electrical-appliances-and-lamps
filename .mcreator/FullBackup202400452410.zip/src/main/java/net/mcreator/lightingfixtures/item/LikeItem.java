
package net.mcreator.lightingfixtures.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LikeItem extends Item {
	public LikeItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON).jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(LightingfixturesMod.MODID, "like"))));
	}
}
