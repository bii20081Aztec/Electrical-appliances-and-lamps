
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lightingfixtures.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LightingfixturesModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, LightingfixturesMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> CALLING_SOUNDS = REGISTRY.register("calling_sounds", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("lightingfixtures", "calling_sounds")));
	public static final DeferredHolder<SoundEvent, SoundEvent> AZXS = REGISTRY.register("azxs", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("lightingfixtures", "azxs")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LIKE = REGISTRY.register("like", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("lightingfixtures", "like")));
}
