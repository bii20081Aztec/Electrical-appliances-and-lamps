
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lightingfixtures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LightingfixturesModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LightingfixturesMod.MODID);
	public static final RegistryObject<CreativeModeTab> SWITCHSOCKETSANDFANS = REGISTRY.register("switchsocketsandfans",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.lightingfixtures.switchsocketsandfans")).icon(() -> new ItemStack(LightingfixturesModBlocks.SINGLESWITCHSWITCH.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LightingfixturesModBlocks.SINGLESWITCHSWITCH.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DOUBLEOPENSWITCH.get().asItem());
				tabData.accept(LightingfixturesModBlocks.THREEONSWITCH.get().asItem());
				tabData.accept(LightingfixturesModBlocks.QUADRUPLESWITCH.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ONEOPENTHREEPINSOCKET.get().asItem());
				tabData.accept(LightingfixturesModBlocks.TWOOPENTHREEPINSOCKET.get().asItem());
				tabData.accept(LightingfixturesModBlocks.SEVENPINSOCKET.get().asItem());
				tabData.accept(LightingfixturesModBlocks.T_VSOCKET.get().asItem());
				tabData.accept(LightingfixturesModBlocks.INTERNETOUTLETS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.GASMETERS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALCABINETS_1X_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALCABINETS_1_X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALCABINETS_2X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALCABINETS_2X_3.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_1X_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRICALBOXWITHELECTRICITYMETER_2X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ACCESSCONTROLINTERCOMHOST.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ACCESSCONTROLINTERCOMEXTENSION.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> LIGHTINGFIXTURES = REGISTRY.register("lightingfixtures", () -> CreativeModeTab.builder().title(Component.translatable("item_group.lightingfixtures.lightingfixtures"))
			.icon(() -> new ItemStack(LightingfixturesModBlocks.FLUORESCENTLIGHTSFORCLASSROOMS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DOUBLETUBEFLUORESCENTLAMPS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.THREETUBEFLUORESCENTLAMP.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTLIGHTSFORCLASSROOMS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTLIGHTBULBS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRONICSINGLETUBEFLUORESCENTAMPS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ELECTRONICDOUBLETUBEFLUORESCENTLAMPS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.METALHALIDEFLOODLIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.METALHALIDEFLOODLIGHT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTLUMINAIRES.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ALUMINUMTUBESAREFLUORESCENT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ENERGYSAVINGLAMPMEDIUM.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ENERGYSAVINLAMPLARGE.get().asItem());
				tabData.accept(LightingfixturesModBlocks.IODINETUNGSTENLAMP.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DOUBLETUBECEILINGLIGHT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DTUBECEILINGLIGHT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.SINGLE_TUBE_FLUORESCENT_LAMP_WITH_LAMPSHADE.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DOUBLE_TUBE_SINGLESTAND_FLUORESCENT_LAMP_WITH_LAMPSHADE.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DOUBLE_TUBE_FLUORESCENT_LAMPWITH_LAMPSHADE.get().asItem());
				tabData.accept(LightingfixturesModBlocks.THREE_LAMP_FLUORESCENT_LAMPWITH_LAMPSHADE.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENT_LAMP_HOLDERS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.FLUORESCENTDOUBLEBRACKET.get().asItem());
			})

			.build());
	public static final RegistryObject<CreativeModeTab> LE_DLUMINAIRES = REGISTRY.register("le_dluminaires",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.lightingfixtures.le_dluminaires")).icon(() -> new ItemStack(LightingfixturesModBlocks.ALUMINUMGUSSET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LightingfixturesModBlocks.CEILING.get().asItem());
				tabData.accept(LightingfixturesModBlocks.CLASSROOM_LED_LIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LE_DPANELLIGHT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LE_DCANOPYLIGHT_1_X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LE_DCANOPYLIGHT_2_X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ALUMINUMGUSSET.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ALUMINUMGUSSET_1_X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.ALUMINUMGUSSET_2_X_2.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LE_DFLOODLIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LED_FLOOD_LIGHT_TOP.get().asItem());
				tabData.accept(LightingfixturesModBlocks.LARGECYLINDERLAMP.get().asItem());
				tabData.accept(LightingfixturesModBlocks.MEDIUMDOWNLIGHT.get().asItem());
				tabData.accept(LightingfixturesModBlocks.SMALLDOWNLIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.TRACKSPOTLIGHTS.get().asItem());
				tabData.accept(LightingfixturesModBlocks.TRACKSPOTLIGHTS_1.get().asItem());
				tabData.accept(LightingfixturesModBlocks.DTUBECEILINGLIGHT.get().asItem());
			})

					.build());
}
