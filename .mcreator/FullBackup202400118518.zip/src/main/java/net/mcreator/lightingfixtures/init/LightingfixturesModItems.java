
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lightingfixtures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LightingfixturesModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LightingfixturesMod.MODID);
	public static final RegistryObject<Item> CEILING = block(LightingfixturesModBlocks.CEILING);
	public static final RegistryObject<Item> SINGLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS);
	public static final RegistryObject<Item> SINGLETUBEFLUORESCENTLAMPS_1 = block(LightingfixturesModBlocks.SINGLETUBEFLUORESCENTLAMPS_1);
	public static final RegistryObject<Item> DOUBLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.DOUBLETUBEFLUORESCENTLAMPS);
	public static final RegistryObject<Item> THREETUBEFLUORESCENTLAMP = block(LightingfixturesModBlocks.THREETUBEFLUORESCENTLAMP);
	public static final RegistryObject<Item> FLUORESCENTLIGHTSFORCLASSROOMS = block(LightingfixturesModBlocks.FLUORESCENTLIGHTSFORCLASSROOMS);
	public static final RegistryObject<Item> CLASSROOM_LED_LIGHTS = block(LightingfixturesModBlocks.CLASSROOM_LED_LIGHTS);
	public static final RegistryObject<Item> FLUORESCENTLIGHTBULBS = block(LightingfixturesModBlocks.FLUORESCENTLIGHTBULBS);
	public static final RegistryObject<Item> LE_DPANELLIGHT = block(LightingfixturesModBlocks.LE_DPANELLIGHT);
	public static final RegistryObject<Item> LE_DCANOPYLIGHT_1_X_2 = block(LightingfixturesModBlocks.LE_DCANOPYLIGHT_1_X_2);
	public static final RegistryObject<Item> LE_DCANOPYLIGHT_2_X_2 = block(LightingfixturesModBlocks.LE_DCANOPYLIGHT_2_X_2);
	public static final RegistryObject<Item> ALUMINUMGUSSET = block(LightingfixturesModBlocks.ALUMINUMGUSSET);
	public static final RegistryObject<Item> ALUMINUMGUSSET_1_X_2 = block(LightingfixturesModBlocks.ALUMINUMGUSSET_1_X_2);
	public static final RegistryObject<Item> ALUMINUMGUSSET_2_X_2 = block(LightingfixturesModBlocks.ALUMINUMGUSSET_2_X_2);
	public static final RegistryObject<Item> FLUORESCENTCEILINGLIGHTS = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS);
	public static final RegistryObject<Item> FLUORESCENTCEILINGLIGHTS_2 = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_2);
	public static final RegistryObject<Item> FLUORESCENTCEILINGLIGHTS_1 = block(LightingfixturesModBlocks.FLUORESCENTCEILINGLIGHTS_1);
	public static final RegistryObject<Item> SINGLESWITCHSWITCH = block(LightingfixturesModBlocks.SINGLESWITCHSWITCH);
	public static final RegistryObject<Item> DOUBLEOPENSWITCH = block(LightingfixturesModBlocks.DOUBLEOPENSWITCH);
	public static final RegistryObject<Item> THREEONSWITCH = block(LightingfixturesModBlocks.THREEONSWITCH);
	public static final RegistryObject<Item> QUADRUPLESWITCH = block(LightingfixturesModBlocks.QUADRUPLESWITCH);
	public static final RegistryObject<Item> LE_DFLOODLIGHTS = block(LightingfixturesModBlocks.LE_DFLOODLIGHTS);
	public static final RegistryObject<Item> LED_FLOOD_LIGHT_TOP = block(LightingfixturesModBlocks.LED_FLOOD_LIGHT_TOP);
	public static final RegistryObject<Item> LARGECYLINDERLAMP = block(LightingfixturesModBlocks.LARGECYLINDERLAMP);
	public static final RegistryObject<Item> MEDIUMDOWNLIGHT = block(LightingfixturesModBlocks.MEDIUMDOWNLIGHT);
	public static final RegistryObject<Item> SMALLDOWNLIGHTS = block(LightingfixturesModBlocks.SMALLDOWNLIGHTS);
	public static final RegistryObject<Item> ELECTRONICSINGLETUBEFLUORESCENTAMPS = block(LightingfixturesModBlocks.ELECTRONICSINGLETUBEFLUORESCENTAMPS);
	public static final RegistryObject<Item> ELECTRONICDOUBLETUBEFLUORESCENTLAMPS = block(LightingfixturesModBlocks.ELECTRONICDOUBLETUBEFLUORESCENTLAMPS);
	public static final RegistryObject<Item> TRACKSPOTLIGHTS = block(LightingfixturesModBlocks.TRACKSPOTLIGHTS);
	public static final RegistryObject<Item> TRACKSPOTLIGHTS_1 = block(LightingfixturesModBlocks.TRACKSPOTLIGHTS_1);
	public static final RegistryObject<Item> METALHALIDEFLOODLIGHTS = block(LightingfixturesModBlocks.METALHALIDEFLOODLIGHTS);
	public static final RegistryObject<Item> METALHALIDEFLOODLIGHT = block(LightingfixturesModBlocks.METALHALIDEFLOODLIGHT);
	public static final RegistryObject<Item> FLUORESCENTLUMINAIRES = block(LightingfixturesModBlocks.FLUORESCENTLUMINAIRES);
	public static final RegistryObject<Item> ALUMINUMTUBESAREFLUORESCENT = block(LightingfixturesModBlocks.ALUMINUMTUBESAREFLUORESCENT);
	public static final RegistryObject<Item> ENERGYSAVINGLAMPMEDIUM = block(LightingfixturesModBlocks.ENERGYSAVINGLAMPMEDIUM);
	public static final RegistryObject<Item> ENERGYSAVINLAMPLARGE = block(LightingfixturesModBlocks.ENERGYSAVINLAMPLARGE);
	public static final RegistryObject<Item> ONEOPENTHREEPINSOCKET = block(LightingfixturesModBlocks.ONEOPENTHREEPINSOCKET);
	public static final RegistryObject<Item> TWOOPENTHREEPINSOCKET = block(LightingfixturesModBlocks.TWOOPENTHREEPINSOCKET);
	public static final RegistryObject<Item> SEVENPINSOCKET = block(LightingfixturesModBlocks.SEVENPINSOCKET);
	public static final RegistryObject<Item> T_VSOCKET = block(LightingfixturesModBlocks.T_VSOCKET);
	public static final RegistryObject<Item> INTERNETOUTLETS = block(LightingfixturesModBlocks.INTERNETOUTLETS);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
