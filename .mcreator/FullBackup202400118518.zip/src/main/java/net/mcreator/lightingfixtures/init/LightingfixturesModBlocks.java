
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lightingfixtures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.lightingfixtures.block.TwoopenthreepinsocketBlock;
import net.mcreator.lightingfixtures.block.TrackspotlightsBlock;
import net.mcreator.lightingfixtures.block.Trackspotlights1Block;
import net.mcreator.lightingfixtures.block.ThreetubefluorescentlampBlock;
import net.mcreator.lightingfixtures.block.ThreeonswitchBlock;
import net.mcreator.lightingfixtures.block.TVsocketBlock;
import net.mcreator.lightingfixtures.block.SmalldownlightsBlock;
import net.mcreator.lightingfixtures.block.SingletubefluorescentlampsBlock;
import net.mcreator.lightingfixtures.block.Singletubefluorescentlamps1Block;
import net.mcreator.lightingfixtures.block.SingleswitchswitchBlock;
import net.mcreator.lightingfixtures.block.SevenpinsocketBlock;
import net.mcreator.lightingfixtures.block.QuadrupleswitchBlock;
import net.mcreator.lightingfixtures.block.OneopenthreepinsocketBlock;
import net.mcreator.lightingfixtures.block.MetalhalidefloodlightsBlock;
import net.mcreator.lightingfixtures.block.MetalhalidefloodlightBlock;
import net.mcreator.lightingfixtures.block.MediumdownlightBlock;
import net.mcreator.lightingfixtures.block.LargecylinderlampBlock;
import net.mcreator.lightingfixtures.block.LEDpanellightBlock;
import net.mcreator.lightingfixtures.block.LEDfloodlightsBlock;
import net.mcreator.lightingfixtures.block.LEDcanopylight2X2Block;
import net.mcreator.lightingfixtures.block.LEDcanopylight1X2Block;
import net.mcreator.lightingfixtures.block.LEDFloodLightTopBlock;
import net.mcreator.lightingfixtures.block.InternetoutletsBlock;
import net.mcreator.lightingfixtures.block.FluorescentluminairesBlock;
import net.mcreator.lightingfixtures.block.FluorescentlightsforclassroomsBlock;
import net.mcreator.lightingfixtures.block.FluorescentlightbulbsBlock;
import net.mcreator.lightingfixtures.block.FluorescentceilinglightsBlock;
import net.mcreator.lightingfixtures.block.Fluorescentceilinglights2Block;
import net.mcreator.lightingfixtures.block.Fluorescentceilinglights1Block;
import net.mcreator.lightingfixtures.block.EnergysavinlamplargeBlock;
import net.mcreator.lightingfixtures.block.EnergysavinglampmediumBlock;
import net.mcreator.lightingfixtures.block.ElectronicsingletubefluorescentampsBlock;
import net.mcreator.lightingfixtures.block.ElectronicdoubletubefluorescentlampsBlock;
import net.mcreator.lightingfixtures.block.DoubletubefluorescentlampsBlock;
import net.mcreator.lightingfixtures.block.DoubleopenswitchBlock;
import net.mcreator.lightingfixtures.block.ClassroomLEDLightsBlock;
import net.mcreator.lightingfixtures.block.CeilingBlock;
import net.mcreator.lightingfixtures.block.AluminumtubesarefluorescentBlock;
import net.mcreator.lightingfixtures.block.AluminumgussetBlock;
import net.mcreator.lightingfixtures.block.Aluminumgusset2X2Block;
import net.mcreator.lightingfixtures.block.Aluminumgusset1X2Block;
import net.mcreator.lightingfixtures.LightingfixturesMod;

public class LightingfixturesModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LightingfixturesMod.MODID);
	public static final RegistryObject<Block> CEILING = REGISTRY.register("ceiling", () -> new CeilingBlock());
	public static final RegistryObject<Block> SINGLETUBEFLUORESCENTLAMPS = REGISTRY.register("singletubefluorescentlamps", () -> new SingletubefluorescentlampsBlock());
	public static final RegistryObject<Block> SINGLETUBEFLUORESCENTLAMPS_1 = REGISTRY.register("singletubefluorescentlamps_1", () -> new Singletubefluorescentlamps1Block());
	public static final RegistryObject<Block> DOUBLETUBEFLUORESCENTLAMPS = REGISTRY.register("doubletubefluorescentlamps", () -> new DoubletubefluorescentlampsBlock());
	public static final RegistryObject<Block> THREETUBEFLUORESCENTLAMP = REGISTRY.register("threetubefluorescentlamp", () -> new ThreetubefluorescentlampBlock());
	public static final RegistryObject<Block> FLUORESCENTLIGHTSFORCLASSROOMS = REGISTRY.register("fluorescentlightsforclassrooms", () -> new FluorescentlightsforclassroomsBlock());
	public static final RegistryObject<Block> CLASSROOM_LED_LIGHTS = REGISTRY.register("classroom_led_lights", () -> new ClassroomLEDLightsBlock());
	public static final RegistryObject<Block> FLUORESCENTLIGHTBULBS = REGISTRY.register("fluorescentlightbulbs", () -> new FluorescentlightbulbsBlock());
	public static final RegistryObject<Block> LE_DPANELLIGHT = REGISTRY.register("le_dpanellight", () -> new LEDpanellightBlock());
	public static final RegistryObject<Block> LE_DCANOPYLIGHT_1_X_2 = REGISTRY.register("le_dcanopylight_1_x_2", () -> new LEDcanopylight1X2Block());
	public static final RegistryObject<Block> LE_DCANOPYLIGHT_2_X_2 = REGISTRY.register("le_dcanopylight_2_x_2", () -> new LEDcanopylight2X2Block());
	public static final RegistryObject<Block> ALUMINUMGUSSET = REGISTRY.register("aluminumgusset", () -> new AluminumgussetBlock());
	public static final RegistryObject<Block> ALUMINUMGUSSET_1_X_2 = REGISTRY.register("aluminumgusset_1_x_2", () -> new Aluminumgusset1X2Block());
	public static final RegistryObject<Block> ALUMINUMGUSSET_2_X_2 = REGISTRY.register("aluminumgusset_2_x_2", () -> new Aluminumgusset2X2Block());
	public static final RegistryObject<Block> FLUORESCENTCEILINGLIGHTS = REGISTRY.register("fluorescentceilinglights", () -> new FluorescentceilinglightsBlock());
	public static final RegistryObject<Block> FLUORESCENTCEILINGLIGHTS_2 = REGISTRY.register("fluorescentceilinglights_2", () -> new Fluorescentceilinglights2Block());
	public static final RegistryObject<Block> FLUORESCENTCEILINGLIGHTS_1 = REGISTRY.register("fluorescentceilinglights_1", () -> new Fluorescentceilinglights1Block());
	public static final RegistryObject<Block> SINGLESWITCHSWITCH = REGISTRY.register("singleswitchswitch", () -> new SingleswitchswitchBlock());
	public static final RegistryObject<Block> DOUBLEOPENSWITCH = REGISTRY.register("doubleopenswitch", () -> new DoubleopenswitchBlock());
	public static final RegistryObject<Block> THREEONSWITCH = REGISTRY.register("threeonswitch", () -> new ThreeonswitchBlock());
	public static final RegistryObject<Block> QUADRUPLESWITCH = REGISTRY.register("quadrupleswitch", () -> new QuadrupleswitchBlock());
	public static final RegistryObject<Block> LE_DFLOODLIGHTS = REGISTRY.register("le_dfloodlights", () -> new LEDfloodlightsBlock());
	public static final RegistryObject<Block> LED_FLOOD_LIGHT_TOP = REGISTRY.register("led_flood_light_top", () -> new LEDFloodLightTopBlock());
	public static final RegistryObject<Block> LARGECYLINDERLAMP = REGISTRY.register("largecylinderlamp", () -> new LargecylinderlampBlock());
	public static final RegistryObject<Block> MEDIUMDOWNLIGHT = REGISTRY.register("mediumdownlight", () -> new MediumdownlightBlock());
	public static final RegistryObject<Block> SMALLDOWNLIGHTS = REGISTRY.register("smalldownlights", () -> new SmalldownlightsBlock());
	public static final RegistryObject<Block> ELECTRONICSINGLETUBEFLUORESCENTAMPS = REGISTRY.register("electronicsingletubefluorescentamps", () -> new ElectronicsingletubefluorescentampsBlock());
	public static final RegistryObject<Block> ELECTRONICDOUBLETUBEFLUORESCENTLAMPS = REGISTRY.register("electronicdoubletubefluorescentlamps", () -> new ElectronicdoubletubefluorescentlampsBlock());
	public static final RegistryObject<Block> TRACKSPOTLIGHTS = REGISTRY.register("trackspotlights", () -> new TrackspotlightsBlock());
	public static final RegistryObject<Block> TRACKSPOTLIGHTS_1 = REGISTRY.register("trackspotlights_1", () -> new Trackspotlights1Block());
	public static final RegistryObject<Block> METALHALIDEFLOODLIGHTS = REGISTRY.register("metalhalidefloodlights", () -> new MetalhalidefloodlightsBlock());
	public static final RegistryObject<Block> METALHALIDEFLOODLIGHT = REGISTRY.register("metalhalidefloodlight", () -> new MetalhalidefloodlightBlock());
	public static final RegistryObject<Block> FLUORESCENTLUMINAIRES = REGISTRY.register("fluorescentluminaires", () -> new FluorescentluminairesBlock());
	public static final RegistryObject<Block> ALUMINUMTUBESAREFLUORESCENT = REGISTRY.register("aluminumtubesarefluorescent", () -> new AluminumtubesarefluorescentBlock());
	public static final RegistryObject<Block> ENERGYSAVINGLAMPMEDIUM = REGISTRY.register("energysavinglampmedium", () -> new EnergysavinglampmediumBlock());
	public static final RegistryObject<Block> ENERGYSAVINLAMPLARGE = REGISTRY.register("energysavinlamplarge", () -> new EnergysavinlamplargeBlock());
	public static final RegistryObject<Block> ONEOPENTHREEPINSOCKET = REGISTRY.register("oneopenthreepinsocket", () -> new OneopenthreepinsocketBlock());
	public static final RegistryObject<Block> TWOOPENTHREEPINSOCKET = REGISTRY.register("twoopenthreepinsocket", () -> new TwoopenthreepinsocketBlock());
	public static final RegistryObject<Block> SEVENPINSOCKET = REGISTRY.register("sevenpinsocket", () -> new SevenpinsocketBlock());
	public static final RegistryObject<Block> T_VSOCKET = REGISTRY.register("t_vsocket", () -> new TVsocketBlock());
	public static final RegistryObject<Block> INTERNETOUTLETS = REGISTRY.register("internetoutlets", () -> new InternetoutletsBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
